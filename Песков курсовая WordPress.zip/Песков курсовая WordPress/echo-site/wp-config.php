<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp' ); define('DB_DIR', __DIR__.'/wp-content/database/'); define('DB_FILE','.ht.sqlite');

/** Database username */
define( 'DB_USER', 'username_here' );

/** Database password */
define( 'DB_PASSWORD', 'password_here' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'f381223e3e7922d185c6ec652c16d46e1955d3bdb2a78c80' );
define( 'SECURE_AUTH_KEY',  '4bcb4966b81a07df070e3bbc5b7bb422d0903d7d854ee705' );
define( 'LOGGED_IN_KEY',    '9afb0a053d4270f95245e8f33bfa88f318efbfc2dae14553' );
define( 'NONCE_KEY',        '21250489f5a82bc0ee3f0c5b91f3b117e249c46c66535a79' );
define( 'AUTH_SALT',        '36c69183eccd8962560e5294bd997eea581cb88ee16e144e' );
define( 'SECURE_AUTH_SALT', '7ee3046be22d0d67a456b319469a59ec75e6c1f5a5820191' );
define( 'LOGGED_IN_SALT',   '980f6ac27ddb811fb9d2c8bd08952197d483633e76c3250b' );
define( 'NONCE_SALT',       '8ae470c42e8645dd3b4d31f9acae8cb74d474c14b70d6d6d' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* ---------- Проверка окружения: понятное сообщение вместо белого экрана ---------- */
if ( ! extension_loaded( 'pdo_sqlite' ) || version_compare( PHP_VERSION, '7.4', '<' ) ) {
	header( 'Content-Type: text/html; charset=utf-8' );
	die( '<div style="font:16px/1.5 Arial;max-width:720px;margin:40px auto">'
		. '<h1>Сайт не может запуститься</h1>'
		. '<p>Версия PHP: <b>' . PHP_VERSION . '</b> (нужна 7.4 или новее).<br>Расширение <b>pdo_sqlite</b>: '
		. ( extension_loaded( 'pdo_sqlite' ) ? 'включено' : '<b style="color:#c00">не включено</b>' ) . '</p>'
		. '<p><b>Как включить pdo_sqlite:</b></p><ol>'
		. '<li>XAMPP: панель XAMPP → Apache → Config → PHP (php.ini). Найдите строки <code>;extension=pdo_sqlite</code> и <code>;extension=sqlite3</code> и удалите точку с запятой в начале.</li>'
		. '<li>OpenServer / OSPanel: Настройки → Модули — выберите PHP 8.x (в нём pdo_sqlite включён).</li>'
		. '<li>Хостинг: панель управления → Версия PHP → отметьте расширение pdo_sqlite.</li>'
		. '<li>Перезапустите Apache и обновите страницу.</li></ol>'
		. '<p>Файл php.ini, который сейчас используется: <code>' . htmlspecialchars( (string) php_ini_loaded_file() ) . '</code></p></div>' );
}

/* ---------- Адрес сайта определяется автоматически ----------
   Работает и в корне домена (http://site.ru/), и в подпапке (http://localhost/echo-site/),
   поэтому базу данных править не нужно. */
if ( isset( $_SERVER['HTTP_HOST'] ) ) {
	$echo_scheme = ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'] ) ? 'https' : 'http';
	$echo_dir    = rtrim( str_replace( '\\', '/', __DIR__ ), '/' );
	$echo_root   = isset( $_SERVER['DOCUMENT_ROOT'] ) ? realpath( $_SERVER['DOCUMENT_ROOT'] ) : false;
	$echo_root   = $echo_root ? rtrim( str_replace( '\\', '/', $echo_root ), '/' ) : '';
	if ( '' !== $echo_root && 0 === stripos( $echo_dir . '/', $echo_root . '/' ) ) {
		$echo_path = substr( $echo_dir, strlen( $echo_root ) );
	} else {
		// Запасной способ: по пути исполняемого скрипта.
		$echo_path = str_replace( '\\', '/', dirname( $_SERVER['SCRIPT_NAME'] ?? '/' ) );
		$echo_path = preg_replace( '#/wp-admin(/.*)?$#', '', $echo_path );
	}
	$echo_path = trim( $echo_path, '/' );
	$echo_path = '' === $echo_path ? '' : '/' . implode( '/', array_map( 'rawurlencode', explode( '/', $echo_path ) ) );
	define( 'WP_HOME', $echo_scheme . '://' . $_SERVER['HTTP_HOST'] . $echo_path );
	define( 'WP_SITEURL', WP_HOME );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
